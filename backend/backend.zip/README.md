# authentication-system
Authentication system using express, passport (local strategy)

## response_status
(login/signup)
1000 - successful
1001 - invalid credential
503 - server error

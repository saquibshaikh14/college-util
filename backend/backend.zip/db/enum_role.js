module.exports =  {
    ADMIN           : 'ADMIN',
    PLACEMENT_CELL  : 'PLACEMENT_CELL',
    EXAM_CELL       : 'EXAM_CELL'
};

//create schema for each key value pair (except admin).